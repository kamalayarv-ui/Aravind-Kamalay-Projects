EXPLAIN ANALYZE
SELECT vehicle_id, odometer_reading
FROM vehicle
WHERE odometer_reading < 20000;
