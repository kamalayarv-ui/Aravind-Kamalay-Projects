EXPLAIN ANALYZE
SELECT vehicle_id, odometer_reading
FROM vehicle
WHERE usage_status = 'In Use';
