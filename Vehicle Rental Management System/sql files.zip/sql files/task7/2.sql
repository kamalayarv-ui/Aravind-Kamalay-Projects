EXPLAIN ANALYZE
SELECT employee_id, ssn
FROM employee
WHERE designation = 'Manager';
