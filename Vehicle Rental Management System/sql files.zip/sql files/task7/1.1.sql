CREATE INDEX idx_vehicle_usage_status
ON vehicle(usage_status);
