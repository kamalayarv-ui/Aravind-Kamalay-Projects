DO $$
BEGIN
    BEGIN
        -- Start of the transaction
        INSERT INTO vehicle (vehicle_id, registration, odometer_reading, usage_status)
        VALUES ('V501', 'REG501', 10000, 'In Use');
        
        -- Force an error: inserting duplicate vehicle_id (Primary Key violation)
        INSERT INTO vehicle (vehicle_id, registration, odometer_reading, usage_status)
        VALUES ('V501', 'REG502', 15000, 'In Use');
        
        COMMIT;
    EXCEPTION WHEN OTHERS THEN
        -- If any error happens during the transaction
        ROLLBACK;
        
        -- Log the transaction failure
        PERFORM log_transaction_failure();
    END;
END;
$$ LANGUAGE plpgsql;
