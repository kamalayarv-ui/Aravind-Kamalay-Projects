SELECT license_number, name
FROM drivinglicense
WHERE license_number NOT IN (
    SELECT driving_license
    FROM customer
);
