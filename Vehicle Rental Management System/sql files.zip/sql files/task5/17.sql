CREATE OR REPLACE PROCEDURE delete_vehicle(
    p_vehicle_id VARCHAR
)
AS $$
BEGIN
    DELETE FROM vehicle
    WHERE vehicle_id = p_vehicle_id;
END;
$$ LANGUAGE plpgsql;
