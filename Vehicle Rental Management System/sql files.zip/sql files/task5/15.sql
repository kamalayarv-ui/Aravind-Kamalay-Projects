CREATE OR REPLACE FUNCTION insert_vehicle(
    p_vehicle_id VARCHAR,
    p_registration VARCHAR,
    p_odometer_reading NUMERIC,
    p_usage_status VARCHAR
)
RETURNS void AS $$
BEGIN
    INSERT INTO vehicle(vehicle_id, registration, odometer_reading, usage_status)
    VALUES (p_vehicle_id, p_registration, p_odometer_reading, p_usage_status);
END;
$$ LANGUAGE plpgsql;
