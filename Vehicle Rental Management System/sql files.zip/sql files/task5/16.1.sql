CALL update_vehicle('V999', 20000, 'Not In Use');
