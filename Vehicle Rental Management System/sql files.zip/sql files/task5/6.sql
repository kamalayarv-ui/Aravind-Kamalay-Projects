SELECT r.vehicle_type, COUNT(*) AS rental_count
FROM rental t
JOIN vehicle v ON t.vehicle_id = v.vehicle_id
JOIN registration r ON v.registration = r.registration
GROUP BY r.vehicle_type
ORDER BY rental_count DESC;
