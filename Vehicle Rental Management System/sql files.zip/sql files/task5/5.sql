SELECT vehicle_id, registration, odometer_reading
FROM vehicle
ORDER BY odometer_reading DESC;
