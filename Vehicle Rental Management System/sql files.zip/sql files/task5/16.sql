CREATE OR REPLACE PROCEDURE update_vehicle(
    p_vehicle_id VARCHAR,
    p_odometer_reading NUMERIC,
    p_usage_status VARCHAR
)
AS $$
BEGIN
    UPDATE vehicle
    SET odometer_reading = p_odometer_reading,
        usage_status = p_usage_status
    WHERE vehicle_id = p_vehicle_id;
END;
$$ LANGUAGE plpgsql;
