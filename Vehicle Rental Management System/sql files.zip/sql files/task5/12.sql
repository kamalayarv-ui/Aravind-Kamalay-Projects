DELETE FROM payment
WHERE payment_id = 'your_payment_id_here';
