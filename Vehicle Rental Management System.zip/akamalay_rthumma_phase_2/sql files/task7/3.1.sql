CREATE INDEX idx_vehicle_odometer_reading
ON vehicle(odometer_reading);
