CREATE INDEX idx_employee_designation
ON employee(designation);
