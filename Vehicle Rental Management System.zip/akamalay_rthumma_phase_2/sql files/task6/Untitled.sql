CREATE TABLE transaction_failure_log (
    log_id SERIAL PRIMARY KEY,
    error_message TEXT,
    failure_time TIMESTAMP DEFAULT NOW()
);
