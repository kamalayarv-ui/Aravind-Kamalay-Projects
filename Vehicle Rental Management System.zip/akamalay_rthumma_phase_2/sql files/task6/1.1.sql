CREATE OR REPLACE FUNCTION log_transaction_failure()
RETURNS void AS $$
BEGIN
    INSERT INTO transaction_failure_log(error_message)
    VALUES ('Transaction failed at ' || NOW());
END;
$$ LANGUAGE plpgsql;
