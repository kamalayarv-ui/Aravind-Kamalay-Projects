SELECT * FROM transaction_failure_log;
