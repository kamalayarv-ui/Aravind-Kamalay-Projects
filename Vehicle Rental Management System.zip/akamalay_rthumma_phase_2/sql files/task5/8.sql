SELECT t.fuel_option, SUM(t.trip_cost) AS total_revenue
FROM rental t
GROUP BY t.fuel_option
ORDER BY total_revenue DESC;
