CALL delete_vehicle('V999');
