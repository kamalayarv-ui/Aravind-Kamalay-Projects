DELETE FROM drivinglicense
WHERE license_number = 'DL2025005';
