SELECT insert_vehicle('V999', 'REG999', 15000, 'In Use');
