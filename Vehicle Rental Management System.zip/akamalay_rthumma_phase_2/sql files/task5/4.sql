SELECT c.customer_id, d.name
FROM customer c
JOIN drivinglicense d ON c.driving_license = d.license_number
WHERE d.name LIKE 'A%';
