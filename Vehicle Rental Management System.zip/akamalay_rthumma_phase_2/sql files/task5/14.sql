CREATE OR REPLACE FUNCTION list_available_vehicles()
RETURNS TABLE(vehicle_id VARCHAR, registration VARCHAR, odometer_reading NUMERIC) AS $$
BEGIN
    RETURN QUERY
    SELECT vehicle_id, registration, odometer_reading
    FROM vehicle
    WHERE usage_status = 'Available';
END;
$$ LANGUAGE plpgsql;
