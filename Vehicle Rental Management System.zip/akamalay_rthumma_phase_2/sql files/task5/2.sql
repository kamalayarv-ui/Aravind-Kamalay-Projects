UPDATE drivinglicense
SET phone_number = '9988776655', email = 'ankit.v@newmail.com'
WHERE license_number = 'DL2025005';
