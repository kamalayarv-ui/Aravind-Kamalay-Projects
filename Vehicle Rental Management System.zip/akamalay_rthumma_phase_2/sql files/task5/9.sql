SELECT e.employee_id, e.designation, COUNT(*) AS handled
FROM rental t
JOIN employee e ON t.employee_id = e.employee_id
GROUP BY e.employee_id, e.designation
ORDER BY handled DESC
LIMIT 5;
