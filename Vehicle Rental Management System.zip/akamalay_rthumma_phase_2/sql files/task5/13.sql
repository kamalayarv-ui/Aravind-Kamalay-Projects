ALTER TABLE rental
DROP CONSTRAINT IF EXISTS rental_payment_id_fkey;

ALTER TABLE rental
ADD CONSTRAINT rental_payment_id_fkey
FOREIGN KEY(payment_id)
REFERENCES payment(payment_id)
ON DELETE CASCADE;
