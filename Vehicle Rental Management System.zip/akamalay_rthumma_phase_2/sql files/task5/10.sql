SELECT r.vehicle_type,
ROUND(
    AVG(EXTRACT(EPOCH FROM (t.drop_off_time - t.pickup_time)) / 3600), 2
) AS avg_hours
FROM rental t
JOIN vehicle v ON t.vehicle_id = v.vehicle_id
JOIN registration r ON v.registration = r.registration
GROUP BY r.vehicle_type;
